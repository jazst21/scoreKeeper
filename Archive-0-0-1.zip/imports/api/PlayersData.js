import { Mongo } from 'meteor/mongo';

export default PlayersData = new Mongo.Collection('PlayersData');
